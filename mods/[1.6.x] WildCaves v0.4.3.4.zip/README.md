==========
WildCaves3
==========

This is the repository for the "Wild Caves 3" mod.

Mod page: http://www.minecraftforum.net/topic/1554854-162forge-wildcaves-3-v0433/


============
Contributing
============
Remember that the idea of the mod is to improve the feeling and look of vanilla caves and not to add new tool sets, armor sets, etc.

If you wish to submit a pull request to fix bugs or broken behaviour feel free to do so.


================
Reporting issues
================

- Before reporting an issue, please check that it has not been reported before.
- Issues are for bugs/crashes, please do not use them to ask general questions.
- Always include the version you are having trouble with. Or if you're building from source, which source you're building.
- If the issues occurs on a server, be sure it's a vanilla forge server.
